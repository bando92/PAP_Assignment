package pap.ass03.viewer;
import java.util.List;

import pap.ass03.Shape;

public interface ShapeViewer {
	
	void update(List<Shape> shapes);

}
