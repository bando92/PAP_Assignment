package pap.ass04.textBall;

public class BoundUtils {
	//limiti della finestra
	public static final int x_min_bound = 1;
	public static final int y_min_bound = 1;
	public static final int x_max_bound = 74;
	public static final int y_max_bound = 49;
}
