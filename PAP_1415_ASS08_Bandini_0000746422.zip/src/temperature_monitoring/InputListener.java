package temperature_monitoring;

public interface InputListener {
	void started();
	
	void stopped();
}