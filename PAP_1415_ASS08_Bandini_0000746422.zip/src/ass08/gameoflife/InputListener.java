package ass08.gameoflife;

public interface InputListener {

	void started();
	
	void stopped();
	
}
