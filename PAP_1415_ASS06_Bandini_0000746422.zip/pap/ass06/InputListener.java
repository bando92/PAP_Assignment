package pap.ass06;

public interface InputListener {

	void started();
	
	void stopped();
	
}
