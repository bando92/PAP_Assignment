package ass07;

public class NumberBound {
	public static final long bound = 2099999999;
}