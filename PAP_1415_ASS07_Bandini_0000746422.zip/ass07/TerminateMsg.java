package ass07;

public class TerminateMsg {
	
	public TerminateMsg ()	{
		
	}
}
