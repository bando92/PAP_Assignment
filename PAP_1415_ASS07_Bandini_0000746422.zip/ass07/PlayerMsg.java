package ass07;


public class PlayerMsg {
	
	private long num;

	public PlayerMsg (long l)	{
		this.num = l;
	}
	
	public long getNumber ()	{
		return num;
	}

}
